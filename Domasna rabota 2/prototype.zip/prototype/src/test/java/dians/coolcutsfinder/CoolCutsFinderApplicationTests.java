package dians.coolcutsfinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoolCutsFinderApplicationTests {

    @Test
    void contextLoads() {
    }

}
