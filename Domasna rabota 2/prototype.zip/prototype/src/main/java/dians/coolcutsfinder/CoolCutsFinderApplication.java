package dians.coolcutsfinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoolCutsFinderApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoolCutsFinderApplication.class, args);
    }

}
